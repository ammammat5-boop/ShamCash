import SwiftUI
import WebKit

@main
struct ShamCashWebApp: App {
    var body: some Scene {
        WindowGroup {
            ShamCashWebView().ignoresSafeArea(edges: .bottom)
        }
    }
}

struct ShamCashWebView: View {
    var body: some View {
        NavigationStack {
            WebPage(url: URL(string: "https://www.shamcash.sy/ar/application/home")!)
                .navigationTitle("شام كاش")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { NotificationCenter.default.post(name: .reloadShamCash, object: nil) } label: {
                            Image(systemName: "arrow.clockwise")
                        }.accessibilityLabel("تحديث الصفحة")
                    }
                }
        }.tint(Color(red: 0.05, green: 0.55, blue: 0.31))
    }
}

extension Notification.Name {
    static let reloadShamCash = Notification.Name("reloadShamCash")
}

struct WebPage: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        context.coordinator.webView = webView
        webView.load(URLRequest(url: url))
        NotificationCenter.default.addObserver(context.coordinator, selector: #selector(Coordinator.reload), name: .reloadShamCash, object: nil)
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, WKNavigationDelegate {
        weak var webView: WKWebView?
        @objc func reload() { webView?.reload() }
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
            if url.host == "www.shamcash.sy" || url.host == "shamcash.sy" {
                decisionHandler(.allow)
            } else if navigationAction.navigationType == .linkActivated {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }
    }
}
